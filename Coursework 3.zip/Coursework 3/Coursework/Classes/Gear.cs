﻿namespace Coursework
{
    public partial class frmGear
    {
        public class Gear
        {
            public int GearID { get; set; }
            public string GearName { get; set; }   
        }
    }
}
