﻿namespace Coursework
{
    public partial class frmActions
    {
        public class Actions
        {
            public int actionID { get; set; }
            public string actionDescription { get; set; }  
        }


    }
}
