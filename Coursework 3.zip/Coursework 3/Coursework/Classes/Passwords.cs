﻿namespace Coursework
{
    public partial class frmPassword
    {
        public class Passwords
        {
            public int PasswordID { get; set; }
            public string Password { get; set; }
        }




    }
}
