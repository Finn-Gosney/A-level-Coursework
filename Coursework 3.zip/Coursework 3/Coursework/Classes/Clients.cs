﻿namespace Coursework
{
    public partial class frmClients
    {
        public class Clients 
        {
            public int ClientID { get; set; }
            public string ClientName { get; set; }
        }
    }
}
