﻿namespace Coursework
{
    public partial class frmJobs
    {
        private class JobClients
        {
            public int JobClientID { get; set; }
            public string JobClientName { get; set; }
        }

    }
}
