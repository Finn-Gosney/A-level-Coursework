﻿namespace Coursework
{
    public partial class frmJobActions
    {
        public class JobActions
        {
            public int JobActionID { get; set; }
            public int JobID { get; set; }
            public int ActionID { get; set; }
            public string clientName { get; set; }
        }
    }
}
